const questions = {
  Mathematics: {
    Remember: ["Define a prime number.", "List the first five odd numbers."],
    Understand: ["Explain the difference between even and odd numbers."],
    Apply: ["Solve 2x + 3 = 7."],
    Analyze: ["Compare area and perimeter of a square."],
    Evaluate: ["Justify the use of algebra in solving real problems."],
    Create: ["Design your own math word problem."]
  },
  Science: {
    Remember: ["Name the parts of a plant.", "What is photosynthesis?"],
    Understand: ["Explain how light travels."],
    Apply: ["Use a circuit diagram to light a bulb."],
    Analyze: ["Differentiate between solids and gases."],
    Evaluate: ["Assess the importance of water to living things."],
    Create: ["Invent an experiment to test soil acidity."]
  },
  English: {
    Remember: ["Define a noun.", "List five verbs."],
    Understand: ["Explain the use of adjectives."],
    Apply: ["Use ‘because’ in a sentence."],
    Analyze: ["Compare two poems."],
    Evaluate: ["Critique a short story you read."],
    Create: ["Write a short story about school."]
  }
};

document.getElementById("examForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const subject = document.getElementById("subject").value;
  const level = document.getElementById("bloom").value;
  const output = document.getElementById("output");

  const selectedQuestions = questions[subject][level];

  if (selectedQuestions) {
    output.innerHTML = `<h2>${subject} - ${level} Questions</h2><ol>` +
      selectedQuestions.map(q => `<li>${q}</li>`).join('') +
      '</ol>';
  } else {
    output.innerHTML = "<p>No questions found.</p>";
  }
});
